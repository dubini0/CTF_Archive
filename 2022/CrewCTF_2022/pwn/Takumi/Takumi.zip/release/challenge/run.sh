#!/bin/sh

/app/ynetd -p 1337 /app/template.py
